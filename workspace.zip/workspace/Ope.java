public class Ope{
	private int n;         //index of gndList
	private boolean p;     //maru or batu -> true or false
	
	public Ope(int n,boolean p){
		this.n = n;
		this.p = p;
	}
	
	public int getN(){
		return this.n;
	}
	public boolean getP(){
		return this.p;
	}
}