public class State{
	private AdrList maruList;
	private AdrList batuList;
	private AdrList skyList;
	private AdrList gndList;
	
	public State(AdrList maru,AdrList batu,AdrList sky,AdrList gnd){
		this.maruList = maru;
		this.batuList = batu;
		this.skyList = sky;
		this.gndList = gnd;
	}
	
	public AdrList getMaruList(){
		return this.maruList;
	}
	public AdrList getBatuList(){
		return this.batuList;
	}
	public AdrList getSkyList(){
		return this.skyList;
	}
	public AdrList getGndList(){
		return this.gndList;
	}
	public void show(){
		System.out.println("---------------------------------");
		System.out.println("maruList [" + maruList.toString() + "]");
		System.out.println("batuList [" + batuList.toString() + "]");
		System.out.println("skyList [" + skyList.toString() + "]");
		System.out.println("gndList [" + gndList.toString() + "]");
	}
}